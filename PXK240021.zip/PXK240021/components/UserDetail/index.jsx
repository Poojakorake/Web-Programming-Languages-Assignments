import React, { useEffect, useState } from 'react';
// eslint-disable-next-line import/no-extraneous-dependencies
import axios from 'axios';
import PropTypes from 'prop-types';
import {
  Card,
  CardContent,
  Typography,
  Button,
  CircularProgress,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './styles.css';

function UserDetail({ userId }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    console.log("UserDetail mounted with userId:", userId);
    const fetchUser = async () => {
      try {
        //const response = await axios.get(`/user/${userId}`);
        const response = await axios.get(`http://localhost:3001/user/${userId}`);
        console.log("UserDetail mounted with userId:", userId);
        setUser(response.data);
      } catch (error) {
        console.error('Error fetching user details:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [userId]);

  if (loading) return <CircularProgress />;
  if (!user) return <Typography color="error">User not found</Typography>;

  
  return (
    <Card sx={{ p: 3, boxShadow: 3 }}>
      <CardContent>
        <Typography variant="body1" gutterBottom>
          {user.first_name} {user.last_name}
        </Typography>
        <Typography variant="body1">location: {user.location}</Typography>
        <Typography variant="body1">Occupation: {user.occupation}</Typography>
        <Typography variant="body1">description: {user.description}</Typography>
        <Button
          variant="contained"
          color="primary"
          sx={{ mt: 3 }}
          onClick={() => navigate(`/photos/${userId}`)}
        >
          View Photos
        </Button>
      </CardContent>
    </Card>
  );
}

UserDetail.propTypes = {
  userId: PropTypes.string.isRequired,
};

export default UserDetail;
