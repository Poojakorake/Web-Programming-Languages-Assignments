import React, { useEffect, useState } from 'react';
import { AppBar, Toolbar, Typography } from '@mui/material';
import axios from 'axios';
import './styles.css';

function TopBar({ userId , textContent}) {
  const [user, setUser] = useState(null);
  
  useEffect(() => {
  if (!userId) return;
  const fetchUser = async () => {
  try {
        const response = await axios.get(`http://localhost:3001/user/${userId}`);
        setUser(response.data);
      } catch (error) {
        console.error('Error fetching user details:', error);
      } 
    };

    fetchUser();
  }, [userId]);
  
  return (
    <AppBar className="topbar-appBar" position="absolute">
      <Toolbar>
        <Typography variant="h5" color="inherit">
          Pooja Korake
        </Typography>
        <Typography variant="h5" color="inherit" sx={{ ml: 'auto' }}>
          {user
            ? `${textContent || ''}${user.first_name} ${user.last_name}`
            : ''}
        </Typography>
      </Toolbar>
    </AppBar>
  );
}

export default TopBar;
