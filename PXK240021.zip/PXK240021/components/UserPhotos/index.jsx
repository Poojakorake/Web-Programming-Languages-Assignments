import React, { useEffect, useState } from 'react';
import axios from 'axios';
// eslint-disable-next-line import/no-extraneous-dependencies
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import { Grid, Card, CardMedia, Typography, Button, CircularProgress, Divider } from '@mui/material';

import './styles.css';


// Import all images from the assets/photos folder
const importedImages = import.meta.glob('/images/*.jpg', { eager: true });

// Convert full paths into a clean "filename → URL" map
const images = Object.keys(importedImages).reduce((acc, path) => {
  const fileName = path.split('/').pop(); // e.g. "pic1.jpg"
  acc[fileName] = importedImages[path].default || importedImages[path];
  return acc;
}, {});


function formattedDate(dateTimeStr){
  if (!dateTimeStr) return '';
  // Convert to Date object
  const dateObj = new Date(dateTimeStr.replace(' ', 'T')); // "2025-10-29T14:05:00"

  // Format as needed
  return dateObj.toLocaleString('en-US', {
    weekday: 'short',    // "Wed"
    year: 'numeric',     // "2025"
    month: 'short',      // "Oct"
    day: 'numeric',      // "29"
    hour: '2-digit',     // "02 PM"
    minute: '2-digit',
  });
}

function UserPhotos({ userId }) {
  //const { id } = useParams();
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPhotos = async () => {
      try {
        //const response = await axios.get(`/photosOfUser/${userId}`);
        const response = await axios.get(`http://localhost:3001/photosOfUser/${userId}`);
        setPhotos(response.data);
      } catch (err) {
        console.error('Failed to fetch photos', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPhotos();
  }, [userId]);

  if (loading) return <CircularProgress />;

  return (
    <div>

      <Button
        variant="outlined"
        sx={{ mb: 2 }}
        onClick={() => navigate(`/user/${userId}`)}
      >
        Back to Details
      </Button>

      <Grid container spacing={2}>
        {photos.map((photo) => (
          <Grid item xs={12} sm={6} md={4} key={photo.id}>
            <Card>
              <CardMedia
                component="img"
                height="300"
                image={images[photo.file_name]}
                alt={photo.title || 'User Photo'}
              />
              
              <Typography variant="body2" sx={{ p: 1 }}>
                {formattedDate(photo.date_time)}
              </Typography>

              {/* Divider before comments */}
              {photo.comments && photo.comments.length > 0 && <Divider sx={{ my: 1 }} />}
              {/* Map over comments */}
              {photo.comments && photo.comments.map((c) => (
                <div key={c._id}>
                  <Typography
                    variant="body2"
                    sx={{ mb: 0.5 }}
                  >
                    <strong style={{ cursor: 'pointer' }} onClick={() => navigate(`/user/${c.user._id}`) }>{c.user.first_name} {c.user.last_name}:</strong> {c.comment}
                  </Typography>
                    
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                    {formattedDate(c.date_time)}
                  </Typography>
                </div>
              ))}
              
            </Card>
          </Grid>
        ))}
      </Grid>
    </div>
  );
}

UserPhotos.propTypes = {
  userId: PropTypes.string.isRequired,
};

export default UserPhotos;
