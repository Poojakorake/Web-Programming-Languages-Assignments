import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Divider,
  List,
  ListItemButton,
  ListItemText,
  Typography,
  CircularProgress,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import './styles.css';

function UserList() {
  const [users, setUsers] = useState([]);     // store user data
  const [loading, setLoading] = useState(true); // loading state
  const [error, setError] = useState(null);     // error state
  const navigate = useNavigate();

  // useEffect runs once when component mounts
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        //const response = await axios.get('/user/list'); // Fetch data via HTTP
        const response = await axios.get('http://localhost:3001/user/list'); // Fetch data via HTTP
        setUsers(response.data); // store response data
      } catch (err) {
        console.error('Error fetching users:', err);
        setError('Failed to fetch user list');
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  // Handle loading
  if (loading) {
    return (
      <div className="loading-container">
        <CircularProgress />
        <Typography>Loading users...</Typography>
      </div>
    );
  }
  // Handle error
  if (error) {
    return (
      <Typography color="error">
        {error}
      </Typography>
    );
  }

  return (
    <div>
      <Typography variant="body1">
        User List: {/* (fetched from <code>/user/list</code>) */}
      </Typography>

      <List component="nav">
        {users.map((user, index) => (
          <React.Fragment key={user.id || index}>
            <ListItemButton onClick={() => navigate(`/user/${user._id}`)}>
              <ListItemText
                primary={`${user.first_name} ${user.last_name}`}
              />
            </ListItemButton>
            {index < users.length - 1 && <Divider />}
          </React.Fragment>
        ))}
      </List>
    </div>
  );
}

export default UserList;
